(function($) {
  $(function() {
    $('#mainbtn').click(function(){
      $('.deg0, .deg30, .deg60, .deg90').toggleClass('open');
       $(this).toggleClass('fa-bars');
        $(this).toggleClass('fa-plus');
    });
  });
})(jQuery);