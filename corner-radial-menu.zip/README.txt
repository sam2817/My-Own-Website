A Pen created at CodePen.io. You can find this one at http://codepen.io/mape07/pen/mymGRK.

 